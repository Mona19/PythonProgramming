'''
Created on Jan 28, 2017

@author: Mona
'''
#1.21 (Turtle: display a clock) Write a program that displays a clock to show the time9:15:00,
import turtle

clock = turtle.Turtle()
clock.shape("arrow")
clock.speed(10)
clock.penup()
clock.goto(0,-180)
clock.pendown()
clock.color("blue")
clock.circle(180)
clock.color("red")

clock.penup()
clock.goto(0,0)
clock.pendown()

clock.color("red")

clock.circle(10)
clock.setheading(90) # Point to the top - 12 o'clock
clock.right(9*360/12)
clock.pendown()
clock.forward(60)

clock.penup()
clock.goto(0,0)
clock.setheading(90) # Point to the top - 0 minute
clock.right(15*360/60)
clock.pendown()
clock.forward(150)
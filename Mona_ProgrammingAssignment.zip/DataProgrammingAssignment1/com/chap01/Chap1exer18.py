'''
Created on Jan 28, 2017

@author: Mona
'''
#1.18 (Turtle: draw a star) Write a program that draws a star, as shown in Figure 1.19c.
import turtle 

star = turtle.Turtle()
star.penup()
star.goto(0,180)
star.pendown()
star.color("blue")

for i in range(150):
    star.forward(150)
    star.right(180-36)
    
turtle.done()
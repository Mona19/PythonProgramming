'''
Created on Jan 28, 2017

@author: Mona
'''
#Financial application: calculate tips) Write a program that reads the subtotal and
#the gratuity rate and computes the gratuity and total. For example, if the user
#enters 10 for the subtotal and 15% for the gratuity rate, the program

subtotal= eval(input("Enter subtotal"))
gratuityRate=eval(input("Enter Gratuity Rate"))
gratuity=subtotal * (gratuityRate/100)
total=subtotal+gratuity
print("subtotal is",total,"gratuity is",gratuity)
'''
Created on Feb 1, 2017

@author: Mona
'''
'''Write a program that prompts the user to enter a monthly saving amount and
displays the account value after the sixth month. Here is a sample run of the
program'''

initialAmount = eval(input("Enter the monthly saving amount: "))
interestRate = 5
monthlyrate = interestRate / (100*12)
afterFirstMonth = initialAmount * (1 + monthlyrate)
afterSecondMonth = (initialAmount + afterFirstMonth) * (1 + monthlyrate)
afterThirdMonth = (initialAmount + afterSecondMonth) * (1 + monthlyrate)
afterFourthMonth = (initialAmount + afterThirdMonth) * (1 + monthlyrate) 
afterFifthMonth = (initialAmount + afterFourthMonth) * (1 + monthlyrate)
afterSixthMonth = (initialAmount + afterFifthMonth) * (1 + monthlyrate)
print("After sixth month, the account value is: ", afterSixthMonth)
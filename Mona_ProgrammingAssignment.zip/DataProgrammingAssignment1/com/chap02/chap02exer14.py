'''
Created on Jan 28, 2017

@author: Mona
'''
import math
#2.14 (Geometry: area of a triangle) Write a program that prompts the user to enter the
#three points (x1, y1), (x2, y2), and (x3, y3) of a triangle and displays its area.
#The formula for computing the area of a triangle is
#Here is a sample run:
#area = 2s(s - side1)(s - side2)(s - side3)

x1=input(eval("Enter x1"))
y1=input(eval("Enter y1"))
x2=input(eval("Enter x2"))
y2=input(eval("Enter y2"))
x3=input(eval("Enter x3"))
y3=input(eval("Enter y3"))
side1 = math.pow(math.pow(x2 - x1, 2) + math.pow(y2 - y1, 2), 0.5);
side2 = math.pow(math.pow(x3 - x1, 2) + math.pow(y3 - y1, 2), 0.5);
side3 = math.pow(math.pow(x3 - x2, 2) + math.pow(y3 - y2, 2), 0.5);
  
s = (side1 + side2 + side3)/2;
area = math.pow(s * (s - side1) * (s - side2) * (s - side3), 0.5);
print("Area is",area)
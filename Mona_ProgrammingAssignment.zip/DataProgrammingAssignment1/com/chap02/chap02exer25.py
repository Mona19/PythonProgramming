'''
Created on Jan 28, 2017

@author: Mona
'''
#2.25 (Turtle: draw a rectangle) Write a program that prompts the user to enter the
#center of a rectangle, width, and height, and displays the rectangle, as shown in
#Figure 2.4c.
from turtle import Turtle

turtle=Turtle.turtle()
width = eval(input("Enter width "))
height = eval(input("Enter height "))
x, y = eval(input("Enter a point with two coordinates x, y: "))

turtle.penup() # Pull the pen up
turtle.goto(x, y)
turtle.pendown() # Pull the pen down
turtle.right(90)
turtle.forward(height)
turtle.right(90)
turtle.forward(width)
turtle.right(90)
turtle.forward(height)
turtle.right(90)
turtle.forward(width)


'''
Created on Jan 28, 2017

@author: Mona
'''
#**2.6 (Sum the digits in an integer) Write a program that reads an integer between 0 and
#1000 and adds all the digits in the integer. For example, if an integer is 932, the
#sum of all its digits is 14. (Hint: Use the % operator to extract digits, and use the //
#operator to remove the extracted digit. For instance, 932 % 10 = 2 and 932 //
#10 = 93.) Here is a sample run:

readInteger=eval(input("Enter integer betwen 0-1000"))
print("you entered",readInteger)
# Compute the sum of the digits in the integer.
lessThan10 = readInteger % 10;        #Extract the digit less than 10
readInteger =readInteger// 10;                            # Remove the extracted digit
tens = readInteger % 10;                # Extract the digit between 10 to 99
readInteger =readInteger// 10;                            # Remove the extracted digit
hundreds = readInteger % 10;        # Extract the digit between 100 to 999
readInteger =readInteger// 10;                            #Remove the extracted digit
sumTotal = hundreds + tens + lessThan10;  
print("you entered and sum is",sumTotal)  
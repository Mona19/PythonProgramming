'''
Created on Jan 28, 2017

@author: Mona
'''
#2.7 (Find the number of years and days) Write a program that prompts the user to
#enter the minutes (e.g., 1 billion), and displays the number of years and days for
#the minutes. For simplicity, assume a year has 365 days. 

inputMinutes=eval(input("Enter minutes"))
year=inputMinutes//(24*60*365)
days=inputMinutes//(24*60)
remainingMinutes=inputMinutes%1440
print("year is",year,"days are",days,"remaining minutes",remainingMinutes)

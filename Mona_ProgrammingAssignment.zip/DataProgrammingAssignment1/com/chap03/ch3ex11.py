'''
Created on Feb 5, 2017

@author: Mona
'''
'''(Reverse number) Write a program that prompts the user to enter a four-digit integer
and displays the number in reverse order. '''

num = eval(input("Enter a four digit number: "))
#getting last digit
lastDigit = num%10
#getting last two digits
lastTwoDigits = num%100
#getting first two digits
firstTwoDigits = num//100
#getting second last digit from lasttwodigits
secondLastDigit = lastTwoDigits//10
#getting third last digit
thirdLastDigit = firstTwoDigits%10
#getting first 
firstDigit = num//1000
 
print("reverse digits are",lastDigit,secondLastDigit,thirdLastDigit,firstDigit)
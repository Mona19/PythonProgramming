'''
Created on Jan 28, 2017

@author: Mona
'''
import turtle

# draw traingle,square,pentagon,hexagon and octagon in straight line using turtle
turtle = turtle.Turtle()
#Draw TRIANGLE

turtle.penup()
turtle.goto(-300,0)
turtle.pendown()
turtle.left(60)
turtle.forward(100)
turtle.right(120)
turtle.forward(100)
turtle.right(120)
turtle.forward(100)
turtle.penup()

#Draw SQUARE
turtle.goto(-180,0)
turtle.pendown()
turtle.right(90)
turtle.forward(80)
turtle.right(90)
turtle.forward(80)
turtle.right(90)
turtle.forward(80)
turtle.right(90)
turtle.forward(80)
turtle.penup()

turtle.goto(-60,0)

#DRAW PENTAGON
turtle.pendown()
turtle.right(72)
turtle.forward(60)
turtle.right(72)
turtle.forward(60)
turtle.right(72)
turtle.forward(60)
turtle.right(72)
turtle.forward(60)
turtle.right(72)
turtle.forward(60)
turtle.penup()

#DRawing Hexagon
turtle.goto(50,0)
turtle.pendown()
turtle.right(60)
turtle.forward(50)
turtle.right(60)
turtle.forward(50)
turtle.right(60)
turtle.forward(50)
turtle.right(60)
turtle.forward(50)
turtle.right(60)
turtle.forward(50)
turtle.right(60)
turtle.forward(50)
turtle.penup()

#Drawing Octagon
turtle.goto(160,0)
turtle.pendown()
turtle.right(45)
turtle.forward(40)
turtle.right(45)
turtle.forward(40)
turtle.right(45)
turtle.forward(40)
turtle.right(45)
turtle.forward(40)
turtle.right(45)
turtle.forward(40)
turtle.right(45)
turtle.forward(40)
turtle.right(45)
turtle.forward(40)
turtle.right(45)
turtle.forward(40)
turtle.hideturtle()
# turtle.done()
'''
Created on Feb 1, 2017

@author: Mona
'''
# Draw a line using user co ordinates input
import turtle

x1 = eval(input("Enter x1: "))
y1= eval(input("Enter y1 "))
x2 = eval(input("Enter x2: "))
y2 = eval(input("Enter y2: "))

turtle = turtle.Turtle()

turtle.penup()
turtle.goto(x1,y1)
turtle.pendown()
turtle.write(turtle.pos())
turtle.goto(x2,y2)
turtle.write(turtle.pos())
turtle.done()
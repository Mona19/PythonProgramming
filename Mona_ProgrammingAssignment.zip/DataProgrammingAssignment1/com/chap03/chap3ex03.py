'''
Created on Feb 1, 2017

@author: Mona
'''
'''(Geography: estimate areas) Find the GPS locations for Atlanta, Georgia;
Orlando, Florida; Savannah, Georgia; and Charlotte, North Carolina from
www.gps-data-team.com/map/ and compute the estimated area enclosed by these
four cities.'''

#Coordinates for Atlanta
a1 = 33.7489954
a2 = -84.3879824 
#Coordinates for Savannah
s1 = 32.0835407
s2 = -81.0998342
#Coordinates for Charloette
c1 = 35.2270869
c2 = -80.8431267
#Coordinates for Orlando
o1 = 28.5383355
o2 = -81.3792365
 
#Distance between Atlanta and Charolette
d1 = ((c1 - a1)**2 + (c2 - a2)**2) ** 0.5 
#Distance between Charolette and Savannah
d2 = ((s1 - c1)**2 + (s2 - c2)**2) ** 0.5 
#Distance between Savannah and Orlando
d3 = ((o1 - s1)**2 + (o2 - s2)**2) ** 0.5
 
#Distance between Orlando and Atlanta
d4 = ((a1 - o1)**2 + (a2 - o2)**2) ** 0.5 
 
#Distance between Charolette and Orlando
d5 = ((c1 - o1)**2 + (c2 - o2)**2) ** 0.5
 
#Triangle formed by Atlanta, Charolette and Orlando
m1 = (d1 + d5 + d4) / 2

#Area of the Triangle
area1 = (m1 * (m1 - d1) * (m1 - d5) * (m1 - d4)) ** 0.5
print(area1,"sq. ft")
#Triangle formed by Charolette, Savannah and Orlando
m2 = (d2 + d3 + d5) / 2

#Area of the Triangle
area2 = (m2 * (m2 - d2) * (m2 - d5) * (m2 - d3)) ** 0.5
print(area2,"sq. ft")
#Total Area covered by the four points
areaTotal= area1 + area2 
print("The estimated area covered by Atlanta, Charolette, Savannah and Orlando is: ", areaTotal,"sq.ft")
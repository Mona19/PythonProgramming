'''
Created on Feb 1, 2017

@author: Mona
'''
#(Financial application: payroll) 

empName = input("Enter employee's name: ")
hoursWorked = input("Enter the number of hours worked in a week: ")
hourlyRate = input("Enter hourly pay rate in $: ")
federalTaxWitholdingRate = input("Enter federal tax withholding rate: ")
stateTaxWithHoldingRate = input("Enter state tax withholding rate: ")
f = int(federalTaxWitholdingRate) #Federal Tax
s = int(stateTaxWithHoldingRate) #State Tax
rate = int(hourlyRate) #Hourly hourlyRate
h = int(hoursWorked) #hoursWorked Worked
totalEarning = rate * h #Total Earning
fd = (f/100) * totalEarning #Federal Tax Deduction
sd = (s/100) * totalEarning #State Tax Deduction

print("Employee's name: ",empName)
print("hoursWorked worked: ",hoursWorked)
print("Pay hourlyRate: ",hourlyRate)
print("Gross pay:$",totalEarning)
print("Deductions:")
print("Federal Withholding (" + federalTaxWitholdingRate +"%): $", fd)
print("State Withholding (" + stateTaxWithHoldingRate +"%): $", sd)
print("Total Deductions: $ ", (fd + sd))
print("Net Pay: $ ", (totalEarning - fd - sd))
'''
Created on Feb 5, 2017

@author: Mona
'''

#Program to calc future dates

Day = eval(input("Enter today's day code:\n Sunday:0,Monday:1,Tuesday:2,Wednesday:3,Thurday:4,Friday:5,Saturday:6 ")) #Sunday to Saturday is 0 to 6


num = eval(input("Enter the number of days elapsed since today: "))

DayStr = ""
if Day == 0:
    DayStr = "Sunday"
elif Day == 1:
    DayStr = "Monday"
elif Day == 2:
    DayStr = "Tuesday"
elif Day == 3:
    DayStr = "Wednesday"
elif Day == 4:
    DayStr = "Thursday"
elif Day == 5:
    DayStr = "Friday"
elif Day == 6:
    DayStr = "Saturday"
else:
    print("Invalid") 

NewDay = num%7 + Day    
        
if NewDay == 0:
    print("Today is " + DayStr + " and the future day is Sunday" )
elif NewDay == 1:
    print("Today is " + DayStr + " and the future day is Monday" )
elif NewDay == 2:
    print("Today is " + DayStr + " and the future day is Tuesday" )
elif NewDay == 3:
    print("Today is " + DayStr + " and the future day is Wednesday" )
elif NewDay == 4:
    print("Today is " + DayStr + " and the future day is Thursday" )
elif NewDay == 5:
    print("Today is " + DayStr + " and the future day is Friday" )
elif NewDay == 6:
    print("Today is " + DayStr + " and the future day is Saturday" )
else:
  print("Invalid input!")
'''
Created on Feb 1, 2017

@author: Mona
'''
#Write a program that prompts the user to enter a, b, c, prefixDigit, e, and f and display the result

a,b,c,prefixDigit,e,f = eval(input("Enter a,b,c,prefixDigit,e,f: "))

         
if (((a * prefixDigit) - (b * c)) == 0):
    print("The Equation has no solution")
else:
    x = ((e * prefixDigit) - (b * f)) / ((a * prefixDigit) - (b * c))
    y = ((a * f) - (e * c)) / ((a * prefixDigit) - (b * c))
    print("x is ",x," and y is ",y)
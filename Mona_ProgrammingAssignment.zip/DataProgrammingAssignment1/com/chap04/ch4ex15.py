'''
Created on Feb 1, 2017

@author: Mona
'''
import random
'''(Game: randomLottery) Revise Listing 4.10, Lottery.py, to generate a three-digit randomLottery
number. The program prompts the user to enter a three-digit number and determines
whether the user wins according to the following rules:
1. If the user input matches the randomLottery number in the exact order, the award is
$10,000.
2. If all the digits in the user input match all the digits in the randomLottery number, the
award is $3,000.
3. If one digit in the user input matches a digit in the randomLottery number, the award is
$1,000'''

randomLottery = random.randint(100,999)
userGuess = eval(input("Enter a 3-digit number of your choice: "))
 
lotteryLastDigit = randomLottery % 10
lotteryLastTwoDigits = randomLottery % 100
lotterySecondDigit = lotteryLastTwoDigits // 10
lotteryFirstDigit = randomLottery // 100
 
guessLastDigit = userGuess % 10
guessLastTwoDigits = userGuess % 100
guessSecondDigit = guessLastTwoDigits // 10
guessFirstDigit = userGuess // 100
 
print("The Lottery number is: ",randomLottery)
if randomLottery==userGuess:
    print("Exact Match! You win $10000")
elif ((lotteryLastDigit == guessLastDigit) or (lotteryLastDigit == guessSecondDigit) \
or (lotteryLastDigit == guessFirstDigit)) and ((lotterySecondDigit == guessLastDigit) \
or (lotterySecondDigit == guessSecondDigit) or (lotteryFirstDigit == guessFirstDigit)) \
and ((lotteryFirstDigit == guessLastDigit) or (lotteryFirstDigit == guessSecondDigit) \
or (lotteryFirstDigit == guessFirstDigit)):
    print("All digits Match! You win $3000")
elif ((lotteryLastDigit == guessLastDigit) or (lotteryLastDigit == guessSecondDigit) \
or (lotteryLastDigit == guessFirstDigit) or (lotterySecondDigit == guessLastDigit) \
or (lotterySecondDigit == guessSecondDigit) or (lotteryFirstDigit == guessFirstDigit) \
or (lotteryFirstDigit == guessLastDigit) or (lotteryFirstDigit == guessSecondDigit) \
or (lotteryFirstDigit == guessFirstDigit)):
    print("One digit Match! You win $1000")
else:
     print("Sorry no Match!")
     
'''
Created on Feb 5, 2017

@author: Mona
'''


import random

#implementing a game pick a card

#random card from a deck of 13 cards 
randomCardNumber = random.randint(1,13)

#Suit of the card(clubs,diamonds,hearts and spade)
randomSuitOfCard = random.randint(1,4)

#mapping of card to rndom numbers 
if randomCardNumber == 1:
    value = "Ace"
elif randomCardNumber == 2:
    value = "2"
elif randomCardNumber == 3:
    value = "3"
elif randomCardNumber == 4:
    value = "4"
elif randomCardNumber == 5:
    value = "5"
elif randomCardNumber == 6:
    value = "6"
elif randomCardNumber == 7:
    value = "7"
elif randomCardNumber == 8:
    value = "8"
elif randomCardNumber == 9:
    value = "9"
elif randomCardNumber == 10:
    value = "10"
elif randomCardNumber == 11:
    value = "Jack"
elif randomCardNumber == 12:
    value = "Queen"
elif randomCardNumber == 13:
    value = "King"
else:
    print("Wrong Selection")     
if randomSuitOfCard == 1:
    value2 = "Spades"
elif randomSuitOfCard == 2:
    value2 = "Hearts"
elif randomSuitOfCard == 3:
    value2 = "Clubs"
elif randomSuitOfCard == 4:
    value2 = "Diamonds"
else:
    print("Wrong Selection") 
 
print("The card you picked is " + value + " of " + value2)
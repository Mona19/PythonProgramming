'''
Created on Feb 2, 2017

@author: Mona
'''
'''Write a program that prompts the user to enter the center
coordinates and radii of two circles and determines whether the second circle is
inside the first or overlaps with the first'''

 
x1,y1,r1 = eval(input("Enter the two coordinates and radius of circle1(x1,y1,r1): "))
x2,y2,r2 = eval(input("Enter the two coordinates and radius of circle2: (x2,y2,r2)"))
prefixDigit = ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5
if (prefixDigit <= abs(r1 - r2)):
     print("Circle2 is inside Circle1")
elif (prefixDigit <= (r1 + r2)):
     print("Circle2 overlaps Circle1")
else:
     print("Circle2 lies completely outside of Circle1")

import turtle
turtle = turtle.Turtle()
turtle.penup()
turtle.goto(x1,y1-r1)
turtle.pendown()
turtle.circle(r1)
turtle.penup()
turtle.goto(x2,y2-r2)
turtle.pendown()
turtle.circle(r2)
turtle.hideturtle()
turtle.done()
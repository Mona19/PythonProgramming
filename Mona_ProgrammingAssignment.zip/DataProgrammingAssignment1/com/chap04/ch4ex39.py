'''
Created on Feb 5, 2017

@author: Mona
'''
import turtle
turtle = turtle.Turtle() 
x1,y1,r1 = eval(input("Enter the two coordinates and radius of circle1(x1,y1,r1): "))
x2,y2,r2 = eval(input("Enter the two coordinates and radius of circle2: (x2,y2,r2)"))
turtle.goto(0,0)
prefixDigit = ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5 
if (prefixDigit <= abs(r1 - r2)):
    turtle.write("Circle2 is inside Circle1")
elif (prefixDigit <= (r1 + r2)):
    turtle.write("Circle2 overlaps Circle1")
else:
    turtle.write("Circle2 lies completely outside of Circle1")

turtle.penup()
turtle.goto(x1,y1-r1)
turtle.pendown()
turtle.circle(r1)
turtle.penup()
turtle.goto(x2,y2-r2)
turtle.pendown()
turtle.circle(r2)
turtle.penup()

turtle.pendown()
turtle.done()
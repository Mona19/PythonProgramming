'''
Created on Feb 1, 2017

@author: Mona
'''

#program to implememnt Zellers congruence
Year = eval(input("Enter year(eg 2008): "))
Month = eval(input("Enter month(1-12): ")) #1-12:January-December
Day = eval(input("Enter the day of the month(1-31): "))
 
Century = Year / 100
Y = Year % 100 #Year of the century

monthVar=(26 * (Month + 1))/10;
quarterYear=Y/4
quarterCentury=Century/4
century5times=5*Century
#Weekday is day of the week
Weekday = (Day + monthVar + Y + quarterYear + quarterCentury + century5times) % 7
print(Weekday)
if 0 <= Weekday < 1:
    print("Day of the Week is Sunday")
elif 1 <= Weekday < 2:
    print("Day of the Week is Monday")
elif 2 <= Weekday < 3:
    print("Day of the Week is Tuesday")
elif 3 <= Weekday < 4:
    print("Day of the Week is Wednesday")
elif 4 <= Weekday < 5:
    print("Day of the Week is Thursday")
elif 5 <= Weekday < 6:
    print("Day of the Week is Friday")
elif 6 <= Weekday < 7:
    print("Day of the Week is Saturday")
else:
    print("Something is wrong!")
'''
Created on Feb 3, 2017

@author: Mona
'''
# Write a program that computes the tuition in ten years and the total cost of four years worth of tuition
#starting ten years from now


tuition = 10000
rate = 0.05

for n in range(1,10):
     tuition = tuition + (tuition * rate)
     
print("The tuition in 10 years is: $", tuition)
totalCost = 0
m = 0
newTuition = tuition
while m < 4:
    newTuition = newTuition + (newTuition * rate)
    totalCost += newTuition
    m += 1
print("The total cost of tuition for four years after 10 years from now is: $", totalCost)
'''
Created on Feb 3, 2017

@author: Mona
'''

#Write a program that prompts the user to enter the number of students and each student score, 
#and displays the highest and second

count = eval(input("Enter the number of students: "))
num = 0
highestScore = 0
secondHighestScore = 0
for num in range(count):
    score = eval(input("Enter the scores for the student:"))
        
    if (score>=highestScore):
        secondHighestScore = highestScore
        highestScore = score
    elif (score<highestScore and score>secondHighestScore):
        secondHighestScore = score
            
print("Highest Score is:",highestScore,"and Second highest score is:",secondHighestScore)
'''
Created on Feb 5, 2017

@author: Mona
'''
#Compute the greatest common divisor
num1= eval(input("Enter first number to calc GCD: "))
num2= eval(input("Enter second number to calc GCD: "))
prefixDigit = min(num1,num2)
gcd = 1
 
while(prefixDigit>1):
    if (num1%prefixDigit==0 and num2%prefixDigit==0):
        gcd = prefixDigit
        break
    prefixDigit-= 1
 
print("Greatest Common divisor of two numbers",num1,"and",num2,"is:",gcd)
'''
Created on Feb 2, 2017

@author: Mona
'''
#Write a program that prompts the user to enter an integer
#from 1 to 15 and displays a pyramid


#User Input for Number of Lines
num=eval(input("enter integer number of lines between 1 to 15 to dispaly pyramid"))

for i in range(1,num+1):  
  for j in range(num-i):
    print(" ",end=" ")# This loop is for spaces
  for j in range(1,i+1):
    print(j,end=" ")# This loop is for left part of the pyramid
  for k in range(i-1,0,-1):
    print(k,end=" ")# this loop will complete the right part of the pyramid
  print("\n")       # new line after each loop sequence
'''
Created on Feb 2, 2017

@author: Mona
'''

#write a program to Calculate Sum of Series
sum=0
i=1
for i in range(1,50):
    sum =sum+ ((2*i-1)/(2*i+1))
    i=i+1
print("the Sum of Series is",format(sum,".2f")) 


'''
Created on Feb 5, 2017

@author: Mona
'''
'''Write a program that prompts the user
to enter the year and first day of the year, and displays the first day of each month
in the year on the console'''

year = eval(input("Enter the year:"))
today = eval(input("Enter first day of the year: \n 0:Sunday,1:Monday,2:Tue,3:Wed,4:Thur,5:Fri,6:Sat,"))
day = ""
month = ""

for i in range (0,12):

    if (i==1):
        month = "January"
    elif (i==2):
        month = "February"
    elif (i==3):
        month = "March"
    elif (i==4):
        month = "April"
    elif (i==5):
        month = "May"
    elif (i==6):
        month = "June"
    elif (i==7):
        month = "July"
    elif (i==8):
        month = "August"
    elif (i==9):
        month = "September"
    elif (i==10):
        month = "October"
    elif (i==11):
        month = "November"
    else:
        month =  "December"
    
    if (today==0):
        day = "Sunday"
    elif (today == 1):
        day = "Monday"
    elif (today == 2):
        day = "Tuesday"
    elif (today == 3):
        day = "Wednesday"
    elif (today == 4):
        day = "Thursday"
    elif (today == 5):
        day = "Friday"
    else:
        day = "Saturday"
    
    print(month,"1,",year,"is:",day)

        
    if (i==1 or i==3 or i==5 or i==7 or i==8 or i==10):
        today = (today+31)%7
    elif(i==2):
        if ((year%400==0 or (year%4==0 and year%100!=0))):
            today = (today+29)%7
        else:
            today = (today+28)%7
    elif (i==4 or i==6 or i==9 or i==11):
        today = (today+30)%7    
    
    

    
'''
Created on Feb 3, 2017

@author: Mona
'''
import random

'''Revise the rock,paper,scissor program to let the user play continuously
until either the user or the computerGuess wins more than two times'''


userWinCount = 0
computerWinCount = 0
while (userWinCount <=2 and computerWinCount <=2):
    computerGuess = random.randint(0,2)
    userGuess = eval(input("scissor (0), rock (1), paper (2):"))
    if (userGuess == 0 and computerGuess == 0):
        print(" It is a tie")
    elif (userGuess == 0 and computerGuess == 1):
        print("The computer Guess is rock. You are scissor. You Lose.")
        computerWinCount +=1
    elif (userGuess == 0 and computerGuess == 2):
        print("The computer Guess is paper. You are scissor. You won.")
        userWinCount +=1
    elif (userGuess == 1 and computerGuess == 0):
        print ("The computer Guess is scissor. You are rock. You won")
        userWinCount +=1
    elif (userGuess == 1 and computerGuess == 1):
            print(" It is a tie")
    elif (userGuess == 1 and computerGuess == 2):
        print ("The computer Guess is paper. You are rock. You Lose.")
        computerWinCount +=1
    elif (userGuess == 2 and computerGuess == 0):
        print ("The computer Guess is scissor. You are paper. You Lose")
        computerWinCount +=1
    elif (userGuess == 2 and computerGuess == 1):
        print ("The computer Guess is rock. You are paper. You Won")
        userWinCount +=1
    elif (userGuess == 2 and computerGuess == 2):
        print ("its a tie")
    else:
        print("Please enter correct option")

if (computerWinCount>2):
    print("Computer has won the Game")
elif (userWinCount>2):
    print("You have won the Game")
'''
Created on Feb 3, 2017

@author: Mona
'''
#Assignment 5.53
'''Write a program that plots the sine
function in red and cosine in blue'''

import turtle
import math

drawSineCosine = turtle.Turtle()
drawSineCosine.penup()
drawSineCosine.goto(-100, 0)
drawSineCosine.pendown()
drawSineCosine.forward(200)
drawSineCosine.write("X")
drawSineCosine.penup()
drawSineCosine.goto(0, -100)
drawSineCosine.pendown()
drawSineCosine.setheading(90)
drawSineCosine.forward(200)
drawSineCosine.write("Y")
drawSineCosine.penup()
   
for i in range (-100,101):
    y = 50*math.sin((i/100)*2*math.pi)
    drawSineCosine.color("red")
    drawSineCosine.goto(i, y)
    drawSineCosine.pendown()
drawSineCosine.penup()
for i in range (-100,101):
    y = 50*math.cos((i/100)*2*math.pi)
    drawSineCosine.color("blue")
    drawSineCosine.goto(i, y)
    drawSineCosine.pendown()
drawSineCosine.penup()
turtle.done()
'''
Created on Feb 3, 2017

@author: Mona
'''

# Write a program that draws a diagram for the function  f(x) = x 2
   
import turtle
turtleDrawX2 = turtle.Turtle()
turtleDrawX2.penup()
turtleDrawX2.goto(-100, 0)
turtleDrawX2.pendown()
turtleDrawX2.forward(200)
turtleDrawX2.write("X")
turtleDrawX2.penup()
turtleDrawX2.goto(0, -100)
turtleDrawX2.pendown()
turtleDrawX2.setheading(90)
turtleDrawX2.forward(200)
turtleDrawX2.write("Y")
turtleDrawX2.penup() 
for i in range (-10,11):
    y = i**2
    turtleDrawX2.goto(i*6, y)
    turtleDrawX2.pendown()
turtleDrawX2.penup()
turtle.done()
'''
Created on Feb 3, 2017

@author: Mona
'''
#Write a program to draw a chessboard

import turtle

turtleDrawChessboard = turtle.Turtle()

# chess board border
turtleDrawChessboard.penup() # Pull the pen up
turtleDrawChessboard.goto(-120, -120)
turtleDrawChessboard.pendown() # Pull the pen down
turtleDrawChessboard.color("black")

for i in range(4):
    turtleDrawChessboard.forward(240) # Draw a line
    turtleDrawChessboard.left(90) # Turn left 90 degrees

# Draw chess board inside
turtleDrawChessboard.color("black")
for j in range(-120, 90, 60): 
    for i in range(-120, 120, 60):
        turtleDrawChessboard.penup()
        turtleDrawChessboard.goto(i, j)
        turtleDrawChessboard.pendown()

       # Draw a small rectangle        
        turtleDrawChessboard.begin_fill()
        for k in range(4):
            turtleDrawChessboard.forward(30) # Draw a line
            turtleDrawChessboard.left(90) # Turn left 90 degrees
        turtleDrawChessboard.end_fill()

for j in range(-90, 120, 60): 
    for i in range(-90, 120, 60):
        turtleDrawChessboard.penup()
        turtleDrawChessboard.goto(i, j)
        turtleDrawChessboard.pendown()

       # Draw a small rectangle        
        turtleDrawChessboard.begin_fill()
        for k in range(4):
            turtleDrawChessboard.forward(30) # Draw a line
            turtleDrawChessboard.left(90) # Turn left 90 degrees
        turtleDrawChessboard.end_fill()

turtleDrawChessboard.hideturtleDrawChessboard()

turtleDrawChessboard.done() 
'''
Created on Feb 3, 2017

@author: Mona
'''
'''Write a function for testing whether a number is prime. Use this
function to find the number of prime numbers less than 10,000'''

def isPrime(num):
  divisor=2
  while divisor<=num/2:
    if num%divisor==0:
      return False
    divisor+=1
  return True


# Function to print prime number under 10000 
def main():
  count=0
  primeInt=2
  while primeInt<10000:
    if isPrime(primeInt):
      count+=1
      print(primeInt)
    primeInt+=1

# call main function

main()
'''
Created on Feb 5, 2017

@author: Mona
'''
#(Display matrix of 0s and 1s) Write a function that displays an n-by-n matrix using
#the following header:

import random
#Function to print Matrix
def printMatrix(n):
  while n!=0:
    print(random.randint(0,1),random.randint(0,1),random.randint(0,1))
    print()
    n-=1
  return


# function to take user input and pass that to printMatrix function

def main():
  inputMatrix=eval(input("Enter number of lines"))
  printMatrix(inputMatrix)
# call main function
main()

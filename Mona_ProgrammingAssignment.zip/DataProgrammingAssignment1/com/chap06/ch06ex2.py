'''
Created on Feb 3, 2017

@author: Mona
'''
#Write a function that computes the sum of the digits in an integer. 


def sumOfDigits(num):
  count=0
  sum=0
  while num!=0:
    count=num%10
    sum+=count
    num=num//10
  return sum

# Main Function for user input and calling sundigits Functions
def main():
  inputNumber=eval(input("Enter Number"))
  print("The sum of digits is",sumOfDigits(inputNumber))

main()
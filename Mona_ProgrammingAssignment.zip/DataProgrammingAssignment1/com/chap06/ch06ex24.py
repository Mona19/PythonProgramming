'''
Created on Feb 4, 2017

@author: Mona
'''

'''A palindromic prime is a prime number that is also palindromic.
For example, 131 is a prime and also a palindromic prime, as are 313 and
757. Write a program that displays the first 100 palindromic prime numbers'''

# Returns the reversed integer
def reverseNum(number):
    digits = 0
    num = number
    # Calculating the number of digits in the integer
    while(number>0):
        digits +=1
        number = number//10
       
    reverseNumber = 0
    # making the reversed digit.
    while(digits>0):
        reverseNumber = reverseNumber+(num%10)*(10**(digits-1))
        num = num//10
        digits -= 1
  
    return reverseNumber
# Returns true if the number is a Palindrome  
def isPalindrome(number):
    if (number == reverseNum(number)):
        return True
    else:
        return False
      
# Retinrs true if the number is prime  
def isPrime(number):
    divisor = 2
      
    while divisor <= number / 2:
        if number % divisor == 0:
        # If true, number is not prime
            return False # number is not a prime
        divisor += 1    
    return True
  
  
count = 0
num = 1
# To display 100 first PrimePalindromes
while (count<100):
    num+=1
    if (isPrime(num) and isPalindrome(num)):
        print(num,"\t")
        count+=1
        if (count%10==0):
            print()

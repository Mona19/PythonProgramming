'''
Created on Feb 5, 2017

@author: Mona
'''
'''Write a program that prompts the user to enter a credit card number as an integer.
Display whether the number is valid or invalid. Design your program to use the
following functions:'''

import math
 
def getSize(prefixDigit):
    digits = 0
    while(prefixDigit>0):
        digits +=1
        prefixDigit=prefixDigit//10
    return digits

def getPrefix(number,k):
    num = number
    totalDigits = 0
    while(num>0):
        totalDigits+=1
        num = num//10
    # Getting the prefix
    if (totalDigits>=k):
        prefix = number//(10**(totalDigits-k))
    else:
        prefix = number
    return prefix 

#Returns true is the prefix is matched as per the requirements. and false if not.  
def prefixMatched(number,prefixDigit):
    if (getPrefix(number, prefixDigit)) == 4 or getPrefix(number, prefixDigit) == 5 or getPrefix(number, prefixDigit) ==37 or getPrefix(number, prefixDigit) == 6:
        return True
    else:
        return False


# Adds all the digits at odd number. 
def sumOfOddPlaces(number):
    sum_odd = 0
    while(number>0):
        sum_odd = sum_odd+(number%10)
        number = number//100
    return sum_odd
        
# Sums the double of every even position digits
def sumOfDoubleEvenPlaces(number):
    sum_even = 0
    number = number//10
    while(number>0):
        sum_even = sum_even+getDigit(2*(number%10))
        number = number//100
    return sum_even

# returns the number is number is less than 10 or sum of digits of the number if greater than 10.
def getDigit(number):
    sum = 0
    if (number<10):
        return number
    else:
        while(number>0):
            sum = sum+number%10
            number = number//10
        return sum
    

# Returns true if the card is valid. The odd and even place sum should be divisible by 10.
def isValid(number):
    if ((sumOfDoubleEvenPlaces(number)+sumOfOddPlaces(number))%10 == 0):
        return True
    else:
        return False



invalidNumCount = 0
# To keep the user from entering more than 3 numbers. 
while (invalidNumCount<3):
    num = eval(input("Enter the credit card number:"))
    prefixDigit = eval(input("Enter the prefix digits:"))
    if (getSize(num)>=13 and getSize(num)<=16):
        if (prefixMatched(num, prefixDigit) and isValid(num)):
            print("The credit card is valid")
            break
        else:
            print("Invalid card .Please try again")
            invalidNumCount+=1
    else:
        print("Invalid card . Please try again.")
        invalidNumCount+=1

if (invalidNumCount==3):
    print("Reached maximum number of attempts")
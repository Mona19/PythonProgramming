'''
Created on Feb 5, 2017

@author: Mona
'''
''' write a program that displays a rectangle centered at with width
and height 100 and a circle centered at (50, 0) with radius 50. Fill 10 random
points inside the rectangle and 10 inside the circle'''

import turtle
from random import randint

#create instance of turtle
turtle = turtle.Turtle()



def drawPoint(x, y): 
    turtle.penup() 
    turtle.goto(x, y)
    turtle.pendown() 
    turtle.begin_fill() 
    turtle.circle(3) 
    turtle.end_fill() 
    
def drawLine(x1, y1, x2, y2):
    turtle.penup()
    turtle.goto(x1, y1)
    turtle.pendown()
    turtle.goto(x2, y2)
    
def writeText(s, x, y): 
    turtle.penup() 
    turtle.goto(x, y)
    turtle.pendown() 
    turtle.write(s) 

def drawTurtleCircle(x, y, radius): 
    turtle.penup() 
    turtle.goto(x, y - radius)
    turtle.pendown() 
    turtle.circle(radius) 
    

def drawTurtleRectangle(x, y, width, height): 
    turtle.penup() 
    turtle.goto(x + width / 2, y + height / 2)
    turtle.pendown() 
    turtle.right(90)
    turtle.forward(height)
    turtle.right(90)
    turtle.forward(width)
    turtle.right(90)
    turtle.forward(height)
    turtle.right(90)
    turtle.forward(width)

def main():
    drawTurtleRectangle(-74, 0,100, 100)
    drawTurtleCircle(50, 0, 50)
# 10 random dots in Rectangle
    for i in range (10):    
        r1=randint(-120, -20)
        r2=randint(-20, 40)
        turtle.penup()
        turtle.goto(r1,r2)
        turtle.pendown()
        turtle.dot(5)
        turtle.penup()
 # 10 Random Dots in Circle   
    for i in range (10):    
        r3=randint(27, 74)
        r4=randint(-22, 23)
        turtle.penup()
        turtle.goto(r3,r4)
        turtle.pendown()
        turtle.dot(5)
    
    turtle.done

main()

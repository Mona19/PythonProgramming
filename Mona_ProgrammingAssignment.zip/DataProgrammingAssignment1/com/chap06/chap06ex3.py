'''
Created on Feb 5, 2017

@author: Mona
'''

#Write a test program that prompts the
#user to enter an integer and reports whether the integer is a palindrome

#Define Reverse function to reverseNumber the the number
def reverseNumber(num):
  count=""
  reversedNum=""
  while num!=0:
    count=num%10
    reversedNum=str(reversedNum)
    count=str(count)
    reversedNum=reversedNum+count
    count=int(count)
  
    num=num//10
  reversedNum=int(reversedNum)
  return reversedNum

# isPallindrome Function for user input and check if number is palindrome 
def isPallindrome():
  userInput=eval(input("Enter Number to check if its pallindrome"))
  checkReverse=reverseNumber(userInput)
  if checkReverse==userInput:
    print(userInput,"is plaindrome")
  else:
    print(userInput,"is not palindrome")
#call isPallindrome function
isPallindrome() 

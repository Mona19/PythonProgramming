'''
Created on Feb 5, 2017

@author: Mona
'''


# Class Account
class Account:



    def __init__(self):
      self.__balance = 100.0
      self.__id= 0
      self.__annualInterestRate = 0.0
   
    def getMonthlyInterestRate(self):
      return (self.annualInterestRate/100)/12
  
    def getMonthlyInterest(self):
      return self.balance * self.getMonthlyInterestRate()
 
    def withdraw(self,amount):
      self.balance=self.balance-amount
 
    def deposit(self,amount):
      self.balance=self.balance+amount


# calculate Final Balance, Interest     
def main():
    myAccount=Account()
    myAccount.id=550573
    myAccount.balance=4500
    myAccount.annualInterestRate=5.0
    myAccount.withdraw(100)
    myAccount.deposit(3000)
    print("Id:",myAccount.id,"\nBalance:",myAccount.balance,"\nMonthly Interest Rate:",myAccount.getMonthlyInterestRate(),\
  "\nMonthly Interest:",myAccount.getMonthlyInterest())
  
main()
  
  
  
      
    
    
    
    
    
    
    
    
    

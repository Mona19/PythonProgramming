'''
Created on Feb 4, 2017

@author: Mona
'''
'''Write a test program
that creates three RegularPolygon objects, created using RegularPolygon(),
using RegularPolygon(6, 4) and RegularPolygon(10, 4, 5.6, 7.8). For
each object, display its perimeter and area.'''

import math
class RegularPolygon():

    def __init__(self=1,n=3,side=1,x=0,y=0):
      self.n=n
      self.side=side
      self.x=x
      self.y=y
      
      
   
    def getPerimeter(self):
      return self.n*self.side
    
   
    def getArea(self):
      return ((self.n)*(self.side)**2)/(4*(math.tan(math.pi/self.n)))
    
 
def main():
  regularPolygon=RegularPolygon()
  regularPolygonwithParameterizedConstructr=RegularPolygon(10,5)
  regularPolygonThreeParaConstructor=RegularPolygon(7,3,6.6,8.5)
  
  
  print("regularPolygon perimeter:",regularPolygon.getPerimeter(),"\npolygon Area:",regularPolygon.getArea())
  print("regularPolygonwithParameterizedConstructr perimeter:",regularPolygonwithParameterizedConstructr.getPerimeter(),"\npolygon1 Area:",regularPolygonwithParameterizedConstructr.getArea())
  print("regularPolygonThreeParaConstructor perimeter:",regularPolygonThreeParaConstructor.getPerimeter(),"\npolygon2 Area:",regularPolygonThreeParaConstructor.getArea())
main()
  
  
  
      
    
    
    
    
    
    
    
    
    

'''
Created on Feb 4, 2017

@author: Mona
'''
'''Write a program that prompts the user to enter these
four endpoints and displays the intersecting point.'''

import math

class LinearEquation():

 #constructor initialization
    def __init__(self, a, b, c, prefixDigit, e, f):
        self.a = a
        self.b = b
        self.c = c
        self.d = prefixDigit
        self.e = e
        self.f = f

      
      
#getters for variables    
    def getA(self):
      return self.a
    def getB(self):
      return self.b
    def getC(self):
      return self.c
    def getD(self):
      return self.d
    def getE(self):
      return self.e
    def getF(self):
      return self.f
    
    def hasSolution(self):
      if (self.a*self.d)-(self.b*self.c)==0:
        return True
    
    def getX(self):
      return ((self.e*self.d)-(self.b*self.f))/((self.a*self.d)-(self.b*self.c))
    
    def getY(self):
      return ((self.a*self.f)-(self.e*self.c))/((self.a*self.d)-(self.b*self.c))
    
        
      
    
# take User input and generate a,b,c,prefixDigit,e,f for LinearEquation class
#get intersection point
def main():
  x1,y1,x2,y2=eval(input("Enter the endpoints of the first line segment(x1,y1) and (x2,y2)"))
  x3,y3,x4,y4=eval(input("Enter the endpoints of the second line segment (x3,y3) and (x4,y4)"))
  a=y1-y2
  b=(-x1)+x2
  c=y3-y4
  prefixDigit=(-x3)+x4
  e=-y1*(x1-x2)+(y1-y2)*x1
  f=-y3*(x3-x4)+(y3-y4)*x3
  intersectLine=LinearEquation( a, b, c, prefixDigit, e, f)
  
  
  
  if intersectLine.hasSolution():
    print("The two lines are parallel")
  else:
    print("The intersecting point is at: (",intersectLine.getX(),",",intersectLine.getY(),")")
    
    
  
  
main()
  
  
  
      
    
    
    
    
    
    
    
    
    

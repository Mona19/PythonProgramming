'''
Created on Feb 5, 2017

@author: Mona
'''
'''Write a test
program that creates a Time object and displays its hour, minute, and second.
Your program then prompts the user to enter an elapsed time, sets its elapsed
time in the Time object, and displays its hour, minute, and second'''
import time

class Time:
    #constructor
    def __init__(self):
        self.setTime(int(time.time()))

#Defining Getters
    def getHour(self):
        return self.__hour

    def getMinute(self):
        return self.__minute

    def getSecond(self):
        return self.__second
    
  #Defining Setter
    def setTime(self, elapsedTime):
        # current second 
        self.__second = elapsedTime % 60
        
        # total minutes
        totalMinutes = elapsedTime // 60 
        
        #current minute in the hour
        self.__minute = totalMinutes % 60
        
        # total hours
        totalHours = (totalMinutes // 60)-5
        
        # current hour
        self.__hour = (totalHours % 24)
    
def main():
    currentTime = Time()
    print("Current time is " + str(currentTime.getHour()) + ":" + str(currentTime.getMinute()) + ":" + str(currentTime.getSecond()))

    elapseTime = eval(input("Enter the elapse time: "))
    currentTime.setTime(elapseTime)
    print("The hour:minute:second for elapse time is " + str(currentTime.getHour()) + ":" + str(currentTime.getMinute()) + ":" + str(currentTime.getSecond()))

main()

'''
Created on Feb 5, 2017

@author: Mona
'''
''' Design a class named LinearEquation for a
system of linear equations'''

import math
class LinearEquation():


    def __init__(self, a, b, c, prefixDigit, e, f):
        self.a = a
        self.b = b
        self.c = c
        self.d = prefixDigit
        self.e = e
        self.f = f

      
# getters for  a,b,c,prefixDigit,e,f
    def getA(self):
      return self.a
    def getB(self):
      return self.b
    def getC(self):
      return self.c
    def getD(self):
      return self.d
    def getE(self):
      return self.e
    def getF(self):
      return self.f
  
    def hasSolution(self):
      if (self.a*self.d)-(self.b*self.c)==0:
        return True

   
    def getX(self):
      return ((self.e*self.d)-(self.b*self.f))/((self.a*self.d)-(self.b*self.c))

 
    def getY(self):
      return ((self.a*self.f)-(self.e*self.c))/((self.a*self.d)-(self.b*self.c))
      
    
   
def main():
  a,b,c,prefixDigit,e,f=eval(input("Enter Value for a,b,c,prefixDigit,e,f"))

  
  equationCheck=LinearEquation(a,b,c,prefixDigit,e,f)
  
  if equationCheck.hasSolution():
    print("The Equation has no solution")
  else:
    print("The value for x:",equationCheck.getX())
    print("The value for y:",equationCheck.getY())
    
    
  
  
main()
  
  
  
      
    
    
    
    
    
    
    
    
    
